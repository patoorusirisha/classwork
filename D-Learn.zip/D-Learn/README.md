# D-Learn
A simple distance learning android app


# [Some basic features of the app (PPT)](https://onedrive.live.com/View.aspx?resid=52F1F35283E6AEE3!1318&wdSlideId=269&wdModeSwitchTime=1566079750818&authkey=!AHorNb3ThNd-SPE) 


# Made By:

[Akhil Rana](https://github.com/akhil-rana/) 

[Aryan Dev](https://github.com/aryandev1/)

[Pratyashi Dutta](https://github.com/pratyashidutta/)

Shreesh Narayan Singh



# This was prepared as an android training project at Sikkim Manipal Institute of Technology by B.Tech 4th semester students in 2019.



# ScreenShots
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/front1.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/front2.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/front3.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/register1.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/register2.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/register3.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/login1.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/basic1.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/admin1.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/admin2.jpg)
![Admin](https://raw.githubusercontent.com/akhil-rana/D-Learn/master/files/images/updatepass.jpg)
